#ifndef H2B_H
#define H2B_H

#include "H2b_global.h"

class H2B_EXPORT H2b
{
public:
    H2b();
};

#endif // H2B_H
